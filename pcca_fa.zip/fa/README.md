# factor_analysis
Python code to perform Factor Analysis
