# cca
CCA and probabilistic CCA implementations in Python
